import pymysql
db=pymysql.connect(user='root',passwd='',host='localhost',database='meesho')
def addrow(sql):
    cur=db.cursor()
    cur.execute(sql)
    db.commit()
def selectrows(sql):
    cur=db.cursor()
    cur.execute(sql)
    data=cur.fetchall()
    return data
def viewrows(sql):
    cur=db.cursor()
    cur.execute(sql)
    data=cur.fetchone()
    return data
def fone(sql):
    cur=db.cursor()
    cur.execute(sql)
    data=cur.fetchone()
    return data