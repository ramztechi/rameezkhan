from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from products import dbconnection
from django.core.files.storage import FileSystemStorage
from datetime import datetime,date
import random,string


# Create your views here.
def lhome(request):
    sql="select quantity from stock_tble"
    data=dbconnection.selectrows(sql)
    k=0
    data2=[]
    ilist=[]
    ilist2=[]
    ilist3=[]
    for i in data:
        for j in i:
            if j<1:
                ilist.append(j)
                k=k+1
    for i in ilist:
        sql1="select id from stock_tble where quantity='"+str(i)+"'"
        data1=dbconnection.fone(sql1)   
        ilist2.append(data1)                
    for d1 in ilist2:
        for jj in d1:                 
            sql2="SELECT stock_tble.id, catagory.catname, subcat.subcat_name, campany.campany_name,stock_tble.quantity FROM stock_tble INNER JOIN catagory ON stock_tble.cid = catagory.id INNER JOIN subcat ON stock_tble.id = subcat.subcat_id INNER JOIN campany ON stock_tble.id = campany.id where id='"+str(jj)+"'"
            data2=dbconnection.selectrows(sql2)
            ilist3.append(data2)  
    return render(request,'lhome.html',{'k':k,'d':ilist2,'il':ilist,'ee':data2,'oo':ilist3})
def index(request):
    return render(request,'index.html',{})
def managecat(request):
    sql1="select * from catagory"
    a=dbconnection.selectrows(sql1)
    if request.POST.get('caty'):
        cat=request.POST['cat']
        sql="INSERT INTO `catagory`(`catname`) VALUES('"+cat+"')"
        dbconnection.addrow(sql)
        return HttpResponseRedirect("managecat")
    if request.GET.get("nid"):
        rid=request.GET['nid']
        sql="select * from catagory where id='"+rid+"'"
        b=dbconnection.fone(sql)
        if request.POST.get("updcat"):
            cat=request.POST['scat']
            sql1="update catagory set catname='"+cat+"'where id='"+rid+"'"
            dbconnection.addrow(sql1)
            return HttpResponseRedirect("managecat")
        return render(request,'managecat.html',{'a':a,'b':b})    
    return render(request,'managecat.html',{'a':a})
def delcat(request):   
    rid=request.GET['nid']
    sql1="delete from catagory where id='"+rid+"'"
    dbconnection.addrow(sql1)
    return HttpResponseRedirect('managecat')
def managesubcat(request):
    sql1="select * from catagory"
    a=dbconnection.selectrows(sql1)
    sql2="SELECT * FROM `campany`"
    data=dbconnection.selectrows(sql2)
    sql="select subcat.id,catagory.catname,campany.campany_name,subcat.subcat_name,subcat.prize from subcat inner join catagory on subcat.cat_id=catagory.id inner join campany on subcat.campany_id=campany.id"
    b=dbconnection.selectrows(sql)
    if request.POST.get('ad'):
        subc=request.POST['sub']
        comp=request.POST['compa']
        cat=request.POST['cat']
        num=request.POST['num']
        sql3="INSERT INTO `subcat`(`subcat_name`, `campany_id`, `cat_id`, `prize`) VALUES('"+subc+"','"+comp+"','"+cat+"','"+num+"')"
        dbconnection.addrow(sql3)
        return HttpResponseRedirect('managesubcat')
    if request.GET.get("nid"):
        rid=request.GET['nid']
        sql3="select * from subcat where id='"+rid+"'"
        c=dbconnection.fone(sql3)
        if request.POST.get('uad'):
            subc=request.POST['usub']
            comp=request.POST['ucomp']
            num=request.POST['unum']
            sql="update subcat set subcat_name='"+subc+"',prize='"+num+"',company_id='"+comp+"' where id='"+rid+"'"
            dbconnection.addrow(sql)
            return render(request,'managesubcat.html',{'b':b,'a':a,'c':c})
    return render(request,'managesubcat.html',{'b':b,'a':a,'data':data})

def delsub(request):
    rid=request.GET['nid']
    sql="delete from subcat where id='"+rid+"'"
    dbconnection.addrow(sql)
    return HttpResponseRedirect('managesubcat')
def managecamp(request):
    sql1="select * from campany"
    a=dbconnection.selectrows(sql1)
    if request.POST.get('caty'):
        cat=request.POST['cat']
        sql="INSERT INTO `campany`(`campany_name`) VALUES('"+cat+"')"
        dbconnection.addrow(sql)
        return HttpResponseRedirect("managecamp")
    if request.GET.get("nid"):
        rid=request.GET['nid']
        sql="select * from campany where id='"+rid+"'"
        b=dbconnection.fone(sql)
        if request.POST.get("updcat"):
            cat=request.POST['scat']
            sql1="update campany set campany_name='"+cat+"'where id='"+rid+"'"
            dbconnection.addrow(sql1)
            return HttpResponseRedirect("managecamp")
        return render(request,'managecamp.html',{'a':a,'b':b})    
    return render(request,'managecamp.html',{'a':a})
def delcomp(request):
    rid=request.GET['nid']
    sql1="delete from campany where id='"+rid+"'"
    dbconnection.addrow(sql1)
    return HttpResponseRedirect('managecamp')
def managestaff(request):
    if request.method=='POST':
        a=request.POST['n']
        b=request.POST['ag']
        c=request.POST['num']
        d=request.POST['add']
        e=request.POST['un']
        f=request.POST['pas']
        g=request.POST['sal']
        h=request.POST['stat']
        i=request.FILES['im']
        fs=FileSystemStorage()
        fs.save('products/static/pics/'+i.name,i)
        sql="INSERT INTO `addstaff`(`name`, `age`, `phone`, `address`, `email`, `password`,`salary`, `status`,`image`) VALUES('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"','"+i.name+"')"
        dbconnection.addrow(sql)
        sql1="INSERT INTO `login`(`email`, `password`, `utype`) VALUES('"+e+"','"+f+"','staff')"
        dbconnection.addrow(sql1)
        return HttpResponseRedirect('managestaff')
    return render(request,'managestaff.html',{})
def viewstaff(request):
    sql="select * from addstaff"
    a=dbconnection.selectrows(sql)
    return render(request,'viewstaff.html',{'a':a})
def viewsdeta(request):
    sql="select * from addstaff"
    a=dbconnection.selectrows(sql)
    return render(request,'viewsdeta.html',{'a':a})
def ahome(request):
    return render(request,'ahome.html',{})
def login(request):
    if request.method=='POST':
        usr=request.POST['un']
        pw=request.POST['upas']
        sql="SELECT * FROM login where email='"+usr+"' and password='"+pw+"'"
        data=dbconnection.fone(sql)
        d=datetime.now()
        time=d.strftime("%H:%M:%S")
        dat=date.today()
        sql1="INSERT INTO `logdata`(`name`, `login_date`, `login_time`,`logout_time`) VALUES('"+usr+"','"+str(dat)+"','"+time+"','"+time+"')"
        dbconnection.addrow(sql1)
        if data:
            request.session['un']=usr
            if data[3]=='staff':
                if data[4]==1:
                    return HttpResponseRedirect('shome')
                else:
                    msg="your account is deactivated please contact admin"
                    return render(request,'login.html',{'msg':msg})    
            elif data[3]=='admin':
                return HttpResponseRedirect('ahome')
            elif data[3]=='user':
                return HttpResponseRedirect('uhome')
        else:
            msg1="invalid email or password"
            return render(request,'login.html',{'msg':msg1})
    return render(request,'login.html',{})
def shome(request):
    return render(request,'shome.html',{})
def salary(request):
    sql1="SELECT * FROM `addstaff`"
    data1=dbconnection.selectrows(sql1)
    return render(request,'salary.html',{'data1':data1})
def paysalary(request):
    pid=request.GET['aid']
    sql="select * from addstaff WHERE id='"+pid+"' "
    a=dbconnection.fone(sql)
    if request.method=='POST':
        date=request.POST['dt']
        name=request.POST['nm']
        amount=request.POST['sal']
        message=request.POST['msg']
        month=request.POST['mn']
        # addby=request.POST['ab']
        sql2="SELECT * FROM `salary` WHERE staff_name='"+name+"' "
        data2=dbconnection.fone(sql2)
        if data2:
            if data2[3]!=int(amount):
                msg1="salary exceeded"
                return render(request,'paysalary.html',{'msg1':msg1})
            elif data2[5]==month:
                msg2="Already paid"
                return render(request,'paysalary.html',{'msg2':msg2}) 
            else:
                sql="INSERT INTO `salary`( `date`, `staff_name`, `amount`, `message`, `month`, `addby`) VALUES('"+date+"','"+name+"','"+amount+"','"+message+"','"+month+"','admin') "
                dbconnection.addrow(sql)
        elif int(amount)!=a[8]:
            msg3="salary exceeded"
            return render(request,'paysalary.html',{'msg3':msg3})
        else:
            sql="INSERT INTO `salary`( `date`, `staff_name`, `amount`, `message`, `month`, `addby`) VALUES('"+date+"','"+name+"','"+amount+"','"+message+"','"+month+"','admin') "
            dbconnection.addrow(sql)
    return render(request,'paysalary.html',{'a':a})
def updatesalary(request):
    aid=request.GET['aid']
    sql="SELECT * FROM addstaff where id='"+aid+"'"
    data=dbconnection.fone(sql)
    if request.method=='POST':
        newsal=request.POST['sal']
        sql="UPDATE `addstaff` SET `salary`='"+newsal+"' WHERE id='"+aid+"'"
        dbconnection.addrow(sql) 
        return HttpResponseRedirect('viewstaff')
    return render(request,'updatesalary.html',{'data':data})
def ashome(request):
    return render(request,'shome.html',{})
def addcustomer(request):
    if request.method=='POST':
        name=request.POST['nm']
        phone=request.POST['ph']
        address=request.POST['ad']
        us=request.POST['un']
        pas=request.POST['pas']
        img=request.FILES['im']
        fs=FileSystemStorage()
        fs.save('products/static/pics/'+img.name,img)
        sql="INSERT INTO `addcust`(`name`,`phone`,`address`,`username`,`password`,`image`) VALUES('"+name+"','"+phone+"','"+address+"','"+us+"','"+pas+"','"+img.name+"')"
        dbconnection.addrow(sql)
        sql1="INSERT INTO `login`(`email`, `password`, `utype`) VALUES ('"+us+"','"+pas+"','user')"
        dbconnection.addrow(sql1)
    return render(request,'addcustomer.html',{})
def addstock(request):
    un=request.session['un']
    sql="select * from addstaff where email='"+un+"'"
    s=dbconnection.fone(sql)
    sql1="select * from catagory"
    a=dbconnection.selectrows(sql1)
    sql2="select * from campany"
    a1=dbconnection.selectrows(sql2)
    sql3="select * from subcat"
    a2=dbconnection.selectrows(sql3)
    if request.method=='POST':
        cat=request.POST['cat']
        subcat=request.POST['subcat']
        com=request.POST['com']
        qty=request.POST['qty']
        da=request.POST['da']
        amnt=request.POST['num']
       
        # aby=request.POST['aby']
        res=int(qty)*int(amnt)
        sql4="INSERT INTO `stock_updation`(`cid`, `subcat_id`, `campany_id`, `quantity`, `date`, `amount`, `addby`) VALUES ('"+cat+"','"+subcat+"','"+com+"','"+qty+"','"+da+"','"+str(res)+"','staff')"
        dbconnection.addrow(sql4)
        sql5="select * from stock_tble where cid='"+cat+"' and campany_id='"+com+"' and subcat_id='"+subcat+"'"
        data=dbconnection.fone(sql5)
        if data:
            var=data[4]+int(qty)
            sql6="UPDATE stock_tble SET quantity='"+str(var)+"' where cid='"+cat+"' and campany_id='"+com+"' and subcat_id='"+subcat+"'"
            dbconnection.addrow(sql6)
        else:
            sql7="INSERT INTO `stock_tble`(`cid`, `subcat_id`, `campany_id`, `quantity`, `amount`) VALUES ('"+cat+"','"+subcat+"','"+com+"','"+qty+"','"+amnt+"')"
            dbconnection.addrow(sql7)

    return render(request,'addstock.html',{'a':a,'a1':a1,'a2':a2,'s':s})
def leavereq(request):
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    sql2="SELECT * FROM `addstaff`where Email= '"+username+"' "
    data2=dbconnection.fone(sql2) 
    if request.method=='POST':     
        name=request.POST['name']
        # email=request.POST['mail']
        from_date=request.POST['from']
        to_date=request.POST['to']
        reason=request.POST['reason']
        sql="INSERT INTO `leave_req`(`staff_id`, `from_day`, `to_day`, `reason`, `status`) VALUES ('"+name+"','"+from_date+"','"+to_date+"','"+reason+"','Requested')"
        dbconnection.addrow(sql)
    return render(request,'leavereq.html',{'data':data,'data2':data2})
def viewleaverequst(request):
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    sql1="select * from leave_req where Status='Requested'"
    data1=dbconnection.selectrows(sql1)
    return render(request,'viewleaverequst.html',{'data':data,'data1':data1})
def accepted(request):
    pid=request.GET['aid']
    sql4="UPDATE `leave_req` SET Status='Accepted ' where id='"+pid+"'"
    dbconnection.addrow(sql4)
    return HttpResponseRedirect("viewleaverequst")
def rejected(request):
    pid=request.GET['aid']
    sql4="UPDATE `leave_req` SET Status='Rejected ' where id='"+pid+"'"
    dbconnection.addrow(sql4)
    return HttpResponseRedirect("viewleaverequst")
def loginstatus(request):
    if request.method=='POST':
        fd=request.POST['fd']
        td=request.POST['td']
        sql1="SELECT * FROM logdata where login_date between'"+fd+"' and '"+td+"'"
        a=dbconnection.selectrows(sql1)
        return render(request,'loginstatus.html',{'a':a})
    return render(request,'loginstatus.html',{})

def logout(request):
    email=request.session['un']
    sql="select * from login where email='"+email+"' "
    data=dbconnection.fone(sql)
    d=datetime.now()
    time=d.strftime("%H:%M:%S")
    sql1="UPDATE `logdata` SET  `logout_time`='"+time+"',`Status`=1 where name='"+email+"'and Status=0 "
    dbconnection.addrow(sql1)
    return render(request,'lhome.html',{data:'data'})
# def Passwordset(request):
#     if request.method=='POST':
#         us=request.POST['un']
#         sql1="SELECT email FROM addstaff"
#         data1=dbconnection.selectrows(sql1)
#         if us in str(data1):
#             upas=PasswordGen()
#             sql2="UPDATE `addstaff` SET Password='"+upas+"' where email='"+us+"' "
#             dbconnection.addrow(sql2)
#             sql3="UPDATE `login` SET password='"+upas+"' where email='"+us+"' "
#             dbconnection.addrow(sql3)
#             msg="Your New Password is '"+upas+"'"
#             return render(request,'Passwordset.html',{'msg':msg})
#         else:
#             msg=" Invalid Email"
#             return render(request,'Passwordset.html',{'msg':msg})
#     return render(request,'Passwordset.html',{})
def  passwordset(request):
    if request.method=='POST': 
        smail=request.POST['umail']
        sql="select * from addstaff where `email`='"+smail+"'"
        data=dbconnection.fone(sql)
        if data:
            if smail in data:
                sql1="INSERT INTO `passreq`(`staff_id`, `email`, `requset`,`status`) VALUES('"+str(data[0])+"','"+smail+"','Reset Password Request','1')"
                dbconnection.addrow(sql1)
                msg="Reset request submitted, Please contact admin for new password."
                return render(request,'passwordset.html',{'msg':msg})      
        else:
            msg="Invalid Email"
            return render(request,'passwordset.html',{'msg':msg})    
    return render(request,'passwordset.html',{})
def passrest(request):
    sql="select * from passreq where status='1'"
    data=dbconnection.selectrows(sql)
    if data:
        return render(request,'passrest.html',{'data':data})
    else:
        msg1="currently no requst"
        return render(request,'passrest.html',{'msg':msg1})


def resetreq2(request):
    email=request.GET['sid']
    pw=PassGen()
    pwstaff="UPDATE `addstaff` SET `password`='"+pw+"' where email='"+email+"'"
    dbconnection.addrow(pwstaff)
    pwlog="UPDATE `login` SET `password`='"+pw+"' where email='"+email+"'"
    dbconnection.addrow(pwlog)
    sql="UPDATE `passreq` SET `status`='0' where email='"+email+"' and `status`='1'"
    dbconnection.addrow(sql)
    msg="Password reset successfully. New Password for '"+email+"' is '"+pw+"'"
    return render(request,'passrest.html',{'msg':msg})

def PassGen():
    characters = list(string.digits)
    password = []
    for i in range(4):
        password.append(random.choice(characters))
    random.shuffle(password)
    pw="".join(password)
    return pw

def uhome(request):
    return render(request,'uhome.html',{})
def activedeactive(request):
     sql1="SELECT * FROM `addstaff`"
     data1=dbconnection.selectrows(sql1)
     return render(request,'activedeactive.html',{'data1':data1}) 
def active(request):
    pid=request.GET['aid']
    sql4="UPDATE `addstaff` SET Status=1 where email='"+pid+"'"
    dbconnection.addrow(sql4)
    sql5="UPDATE `login` SET Status=1  where email='"+pid+"'"
    dbconnection.addrow(sql5)
    return HttpResponseRedirect("viewstaff") 
def deactive(request):
    pid=request.GET['aid']
    sql4="UPDATE `addstaff` SET Status=0 where email='"+pid+"'"
    dbconnection.addrow(sql4)
    sql5="UPDATE `login` SET Status=0 where email='"+pid+"'"
    dbconnection.addrow(sql5)
    return HttpResponseRedirect("viewstaff")   
def viewstock(request):
    sql2="SELECT stock_tble.id,catagory.catname,campany.Campany_name,subcat.SubCat_name,stock_tble.quantity,stock_tble.amount FROM stock_tble INNER JOIN catagory ON stock_tble.Cid=catagory.Id INNER JOIN campany ON stock_tble.campany_id=campany.Id INNER JOIN subcat ON stock_tble.SubCat_id=subcat.Id"
    data2=dbconnection.selectrows(sql2)
    return render(request,'viewstock.html',{'data2':data2})
def fbill(request):
    sql1="SELECT * FROM `addcust`"
    data1=dbconnection.selectrows(sql1)
    sid=request.session['un']
    if request.method=='POST':
        custid=request.POST['cusid']
        dat=date.today()
        sql2="INSERT INTO `billdata`(`date_sale`, `customer_id`, `amount`, `status`, `addby`) VALUES ('"+str(dat)+"','"+custid+"','0','0','"+sid+"')"
        dbconnection.addrow(sql2)
        return HttpResponseRedirect("/bill2?id="+custid) 
    return render(request,'fbill.html',{'data1':data1})
def bill2(request):
    sql1="SELECT * FROM `catagory`"
    data1=dbconnection.selectrows(sql1)
    sql2="SELECT * FROM `campany`"
    data2=dbconnection.selectrows(sql2)
    sql3="SELECT * FROM `subcat`"
    data3=dbconnection.selectrows(sql3)
    custid=request.GET['id']
    
    dat=date.today()
    sql6="SELECT * FROM `addcust` where Id='"+custid+"'"
    data6=dbconnection.fone(sql6)

    sql4="SELECT * FROM `billdata` WHERE `Customer_id`='"+custid+"' and `date_sale`='"+str(dat)+"' and status='0'"
    data4=dbconnection.fone(sql4)
    sql7="SELECT * FROM `sale_tble` where `bill_No`='"+str(data4[0])+"'"
    data7=dbconnection.selectrows(sql7)
    sid=request.session['un']
    if request.POST.get('addpro'):
        bill=request.POST['bill']
        catid=request.POST['cat']
        subcat=request.POST['sub']
        com=request.POST['com']
        quan=request.POST['qun']
        amount=request.POST['amt']
        var=int(quan)*int(amount)
        sql8="Select quantity from stock_tble where Cid= '"+catid+"' and `SubCat_id`='"+subcat+"' and `campany_id`='"+com+"' "
        data8=dbconnection.fone(sql8)
        sql7="SELECT * FROM `sale_tble` where `bill_No`='"+bill+"'"
        data7=dbconnection.selectrows(sql7)
        if int(data8[0])<int(quan):
            msg="out of stock,Available stock is '"+quan+"'"
            return render(request,'bill2.html',{'msg':msg,'data1':data1,'data2':data2,'data3':data3,'data4':data4,'data6':data6,'data7':data7,'id':custid})
        else:
            sql5="INSERT INTO `sale_tble`(`bill_No`,`date`, `Catid`, `SubCat_id`,`CompanyId`, `quantity`, `amount`, `addby`) VALUES('"+bill+"','"+str(dat)+"','"+catid+"','"+subcat+"','"+com+"','"+quan+"','"+str(var)+"','"+sid+"')"
            dbconnection.addrow(sql5)
            ans=int(data8[0])-int(quan)
            sql9="update stock_tble set quantity='"+str(ans)+"'  where Cid= '"+catid+"' and `SubCat_id`='"+subcat+"' and `campany_id`= '"+com+"' "
            dbconnection.addrow(sql9)

            sql7="SELECT * FROM `sale_tble` where `bill_no`='"+bill+"'"
            data7=dbconnection.selectrows(sql7)
            return HttpResponseRedirect("/bill2?id="+custid)
    elif request.POST.get('Total'):
        var="select sum(Amount) from sale_tble where bill_no='"+str(data4[0])+"'"
        var1=dbconnection.fone(var)
        
        return render(request,'bill2.html',{'data1':data1,'data2':data2,'data3':data3,'data4':data4,'data6':data6,'data7':data7,'id':custid,'var':var1})
    elif request.POST.get('Proceed'):
        var="select sum(Amount) from sale_tble where bill_no='"+str(data4[0])+"'"
        var1=dbconnection.fone(var)
        sql2="UPDATE `billdata` SET Status=1 , Amount='"+str(var1[0])+"' where billno='"+str(data4[0])+"' "
        dbconnection.addrow(sql2)
        return render(request,'bill2.html',{'bilid':data4[0]})
    return render(request,'bill2.html',{'data1':data1,'data2':data2,'data3':data3,'data4':data4,'data6':data6,'data7':data7,'id':custid,'bilid':data4[0]})
    
def delete(request):
    rid=request.GET['pid']
    bid=request.GET['id']
    sql="select * from sale_tble  where id='"+rid+"'"
    data=dbconnection.fone(sql)
    catid=str(data[3])
    subcat=str(data[4])
    com=str(data[5])
    sql="select QUANTITY FROM stock_tble where Cid= '"+catid+"' and `SubCat_id`='"+subcat+"' and `company_id`= '"+com+"' "
    data1=dbconnection.fone(sql)
    q=int(data[6])+int(data1[0])
    sql="update stock_tble set Quantity='"+str(q)+"' where Cid= '"+catid+"' and `SubCat_id`='"+subcat+"' and `company_id`= '"+com+"' "
    dbconnection.addrow(sql)
    sql="delete from sale_tble where id='"+rid+"'"
    dbconnection.addrow(sql)
    return HttpResponseRedirect('http://127.0.0.1:8000/bill2?id='+bid)

def customerdetails(request):
    # username=request.session['un']
    # sql="select * from login where email='"+username+"' "
    # data=dbconnection.fone(sql)
    # sql1="SELECT * FROM `addcust`"
    # data1=dbconnection.selectrows(sql1)
    # return render(request,'customerdetails.html',{'data':data,'data1':data1})
    sql="select * from addcust"
    a=dbconnection.selectrows(sql)
    return render(request,'customerdetails.html',{'a':a})

def updateprofile(request):
    un=request.session['un']
    sql="select * from addstaff where email ='"+un+"'"
    a=dbconnection.fone(sql)
    if request.POST.get('det'):
        name=request.POST['nm']
        address=request.POST['ad']
        phone=request.POST['ph']
        sql="UPDATE `addstaff` SET `name`='"+name+"',`address`='"+address+"',`phone`='"+phone+"' WHERE `email`='"+un+"'"
        dbconnection.addrow(sql)
        return HttpResponseRedirect('updateprofile')
    elif request.POST.get('pic'):
        img=request.FILES['up']
        fs=FileSystemStorage()
        fs.save('products/static/pics/'+img.name,img)
        sql="UPDATE `addstaff` SET `image`='"+img.name+"' WHERE `email`='"+un+"'"
        dbconnection.addrow(sql)
        return HttpResponseRedirect('updateprofile')
    elif request.POST.get('pas'):
        opas=request.POST['opas']
        npas=request.POST['npas']
        cpas=request.POST['cpas']
        if opas in a[8]:
            if npas==cpas:
                sql="UPDATE `addstaff` SET `password`='"+cpas+"' WHERE `email`='"+un+"'"
                dbconnection.addrow(sql)
            else:
                msg="PASSWORD MISMATCH"
                return render(request,'updateprofile.html',{'a':a,'msg':msg})
        else:
            msg="OLD PASSWORD IS WRONG"
            return render(request,'updateprofile.html',{'a':a,'msg':msg})
    return render(request,'updateprofile.html',{'a':a})
def viewstockupdate(request):
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    sql1="SELECT * FROM `addstaff`"
    data1=dbconnection.selectrows(sql1)
    if request.method=='POST':
        dat=request.POST['dat']
        
        sql2="SELECT stock_updation.id,catagory.Catname,campany.Campany_name,subcat.SubCat_name,stock_updation.quantity,stock_updation.addby FROM  stock_updation INNER JOIN catagory ON stock_updation.cid=catagory.Id INNER JOIN campany ON stock_updation.campany_id=campany.Id INNER JOIN subcat ON stock_updation.SubCat_id=subcat.Id WHERE stock_updation.date='"+dat+"' "
        data2=dbconnection.selectrows(sql2)
        return render(request,'viewStockUpdate.html',{'data1':data1,'data2':data2})
    return render(request,'viewStockUpdate.html',{'data':data,'data1':data1})
def viewsales(request):
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    sql2="SELECT date_sale, SUM(Amount) as TotalAmount FROM billdata GROUP BY date_sale"
    data2=dbconnection.selectrows(sql2)
    return render(request,'viewSales.html',{'data':data,'data2':data2})
def dailycollection(request):
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    if request.method=='POST':
        dat=request.POST.get('dat')
        sql1="select sum(Amount) from sale_tble where date='"+dat+"'"
        data1=dbconnection.selectrows(sql1)
        sql2="select sum(amount) from stock_updation Where date='"+dat+"'"
        data2=dbconnection.selectrows(sql2)
        sql3="select sum(amount) from salary where date='"+dat+"'"
        data3=dbconnection.selectrows(sql3)
        return render(request,'dailycollection.html',{'data1':data1[0],'data2':data2[0],'data3':data3[0]})
    return render(request,'dailycollection.html',{'data':data})
def top10(request):
    
    # sql3="INSERT INTO daysorder (ord_date,ord_amount,advance_amount) SELECT ord_date,SUM(ord_amount),SUM(advance_amount) FROM orders GROUP BY ord_date"
    # sql1="select *from billdata where Amount=(select Max(amount) from billdata);"
    # sql1="SELECT *  FROM saledata ORDER BY Amount DESC LIMIT 10" correct query
    # data1=dbconnection.allrow(sql1) 
    # sql2="SELECT billdata.cusid, customerdata.Customer_Name FROM billdata INNER JOIN customerdata ON billdata.cusid = customerdata.id order by billdata.Amount DESC limit 10 "
    # crt query sql2="SELECT customerdata.id,customerdata.Customer_Name,customerdata.Address,customerdata.PhoneNum,billdata.Amount FROM customerdata INNER JOIN billdata ON customerdata.id = billdata.cusid ORDER BY Amount DESC LIMIT 10  "
    # crt query sql2="SELECT DISTINCT customerdata.id,customerdata.Customer_Name,customerdata.Address,customerdata.PhoneNum,billdata.Amount FROM customerdata INNER JOIN billdata ON customerdata.id = billdata.cusid ORDER BY Amount DESC LIMIT 10 "
    username=request.session['un']
    sql="select * from login where email='"+username+"' "
    data=dbconnection.fone(sql)
    sql2="Update addcust SET addcust.amount=(SELECT SUM(billdata.amount) FROM billdata WHERE addcust.Id=billdata.customer_id)"
    dbconnection.addrow(sql2)
    sql3="SELECT *  FROM addcust ORDER BY amount DESC LIMIT 5"
    data3=dbconnection.selectrows(sql3)
    return render(request,'top10.html',{'data':data,'data3':data3})

def purchase1(request):
    sql="update addcust set addcust.amount=(select sum(billdata.amount) from billdata where addcust.id=billdata.customer_id)" 
    dbconnection.addrow(sql)
    sql1="select * from addcust"
    a=dbconnection.selectrows(sql1)
    return render(request,'purchase1.html',{'a':a})

def singlebill(request):
    cid=request.GET['aid']
    sql1="select * from billdata where customer_id='"+cid+"'"
    a=dbconnection.selectrows(sql1)
    return render(request,'singlebill.html',{'a':a})


def purchasedetails(request):
    username=request.session['un']
    sql="select Id from addcust where username='"+username+"' "
    data1=dbconnection.fone(sql)
    for i in data1:
        data=int(i)
    sql="SELECT billno,date_sale,amount FROM billdata WHERE customer_id='"+str(data)+"' "
    data2=dbconnection.selectrows(sql)
    return render(request,'purchaseDetails.html',{'data':data,'data1':data1,'data2':data2})
def purchasebill(request):
    username=request.session['un']
    sql="select * from addcust where username='"+username+"' "
    data=dbconnection.fone(sql)
    rid=request.GET['aid']
    sql1="SELECT Catagory.catname,campany.Campany_Name,subcat.SubCat_name,sale_tble.quantity,sale_tble.amount FROM sale_tble INNER JOIN catagory ON sale_tble.catid=catagory.Id INNER JOIN campany ON sale_tble.CompanyId=campany.Id INNER JOIN subcat ON sale_tble.subcat_id=subcat.Id WHERE sale_tble.bill_no='"+rid+"' " 
    data1=dbconnection.selectrows(sql1)
    sql2="SELECT amount FROM billdata WHERE billno='"+rid+"'"
    data2=dbconnection.fone(sql2)
    return render(request,'Purchasebill.html',{'data':data,'data1':data1,'data2':data2})
def Productdetails(request):
    username=request.session['un']
    sql="select * from addcust where username='"+username+"' "
    data=dbconnection.fone(sql)
    sql1="SELECT * FROM catagory"
    data1=dbconnection.selectrows(sql1)
    if request.method=='POST':
        cat=request.POST.get('cat')
        sql2="SELECT Catagory.catname,campany.Campany_name,subcat.SubCat_name,stock_tble.amount FROM stock_tble INNER JOIN catagory ON stock_tble.Cid=catagory.Id INNER JOIN campany ON stock_tble.campany_id=campany.Id INNER JOIN subcat ON stock_tble.subcat_id=subcat.Id WHERE stock_tble.cid='"+str(cat)+"';  "
        data2=dbconnection.selectrows(sql2)
        return render(request,'productdetails.html',{'data1':data1,'data2':data2})
    return render(request,'productdetails.html',{'data':data,'data1':data1})

def feedback(request):
    un=request.session['un']
    sql4="select id from addcust where username='"+un+"'"
    i=dbconnection.fone(sql4)
    d=datetime.now()
    if request.method=='POST':
        cus=request.POST['cus']
        fb=request.POST['fb']
        sql3="insert into `feedback`(`custid`,`date`,`feedbacks`) values('"+cus+"','"+str(d)+"','"+fb+"')"
        dbconnection.addrow(sql3)
        return HttpResponseRedirect('feedback')
    return render(request,'feedback.html',{'i':i})
def complains(request):
    un=request.session['un']
    sql4="select id from addcust where username='"+un+"'"
    i=dbconnection.fone(sql4)
    d=datetime.now()
    if request.method=='POST':
        cus=request.POST['cus']
        cp=request.POST['cm']
        sql3="insert into `complains`(`custid`,`date`,`complains`) values('"+cus+"','"+str(d)+"','"+cp+"')"
        dbconnection.addrow(sql3)
        return HttpResponseRedirect('complains')
    return render(request,'complains.html',{'i':i})
def viewfeedback(request):
    sql="select feedback.date,addcust.name,addcust.image,addcust.phone,feedback.feedbacks from feedback inner join addcust on feedback.custid=addcust.id"
    a=dbconnection.selectrows(sql)
    return render(request,'viewfeedback.html',{'a':a})
def viewcompliants(request):
    sql="select complains.date,addcust.name,addcust.image,addcust.phone,complains.complains from complains inner join addcust on complains.custid=addcust.id"
    a=dbconnection.selectrows(sql)
    return render(request,'viewcompliants.html',{'a':a})





    

